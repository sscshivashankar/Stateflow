/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: FanControl.c
 *
 * Code generated for Simulink model 'FanControl'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sat Aug 24 16:08:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->Stellaris Cortex-M3
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "FanControl.h"
#include "rtwtypes.h"

/* Named constants for Chart: '<S1>/Chart' */
#define IN_FanOn                       ((uint8_T)1U)
#define IN_OnStart                     ((uint8_T)2U)

/* Block signals and states (default storage) */
DW rtDW;

/* External inputs (root inport signals with default storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;

/* Model step function */
void FanControl_step(void)
{
  /* Chart: '<S1>/Chart' incorporates:
   *  Constant: '<S1>/Constant'
   *  Inport: '<Root>/SetTemperature'
   *  Inport: '<Root>/Temperature'
   */
  if (rtDW.is_active_c3_FanControl == 0U) {
    rtDW.is_active_c3_FanControl = 1U;
    rtDW.is_c3_FanControl = IN_OnStart;

    /* Outport: '<Root>/Fan' */
    rtY.Fan = 0;
  } else if (rtDW.is_c3_FanControl == IN_FanOn) {
    if ((rtU.Temperature < rtU.SetTemperature - 2.0) || (rtU.SetTemperature -
         2.0 > rtU.Temperature)) {
      rtDW.is_c3_FanControl = IN_OnStart;

      /* Outport: '<Root>/Fan' */
      rtY.Fan = 0;
    } else {
      /* Outport: '<Root>/Fan' */
      rtY.Fan = 1;
    }

    /* case IN_OnStart: */
  } else if (rtU.Temperature > rtU.SetTemperature) {
    rtDW.is_c3_FanControl = IN_FanOn;

    /* Outport: '<Root>/Fan' */
    rtY.Fan = 1;
  } else {
    /* Outport: '<Root>/Fan' */
    rtY.Fan = 0;
  }

  /* End of Chart: '<S1>/Chart' */
}

/* Model initialize function */
void FanControl_initialize(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
